class ProductModel {
  String areaName;
  String districtArea;
  String imageArea;
  String id;
  String type;

  ProductModel(
      {required this.areaName,
      required this.districtArea,
      required this.imageArea,
      required this.id,
      required this.type});
}
