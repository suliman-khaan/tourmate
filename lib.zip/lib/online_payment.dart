import 'package:flutter/cupertino.dart';

class OnlinePayment extends StatefulWidget {
  const OnlinePayment({Key? key}) : super(key: key);

  @override
  _OnlinePaymentState createState() => _OnlinePaymentState();
}

class _OnlinePaymentState extends State<OnlinePayment> {
  void _pay() {}
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [],
      ),
    );
  }
}
