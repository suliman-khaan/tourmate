class MyRoute {
  static String tourMate = "/";
  static String MainHome = "/home2";
  static String singleTravel = "/singleTravel";
  static String compTravel = "/CompanyData";
  static String swatHotel = "/swatHotel";
  static String hotel = "/hotel";
  static String transport = "/transport";
  static String resturent = "/resturent";
  static String home = "/home";
  static String searchPage = "/search_page";
  static String formScreen = "/form_screen";
  static String singleHotel = "/view_hotel";
  static String login = "/login";
  static String signup = "/register";
  // ignore: non_constant_identifier_names
  static String explore_area_swat = "/explore_swat";
  static String historicalAreas = "/historical";
  static String test = "/Test";
  static String parks = "/Parks";
  static String singleArea = "/Area";
  static String chukailBandaGallery = "/Chukhail_Banda_Gallery";
  static String allDistinations = "/All_Distination";
  static String viewDistination = "/View_Distination";
  static String contactUs = "/Cntact_Us";
  static String aboutUs = "/aboutUs";
  static String ourTeam = "/OurTeams";
  static String map = "/Map";
  static String review = "/review";
}
