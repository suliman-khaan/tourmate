class Quotes {
  String name;
  String email;
  String image;
  String rank;
  String contact;
  String facebook;
  String facebookLink;
  String description;
  double dashes;
  Quotes(
      {required this.name,
      required this.email,
      required this.image,
      required this.rank,
      required this.dashes,
      required this.contact,
      required this.facebook,
      required this.facebookLink,
      required this.description});
}
